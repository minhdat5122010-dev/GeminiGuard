GEMINI GUARD v2.5
- Upload zip nay len GitHub (cung ten de ghi de), Actions tu build APK.
- Cai APK DE LEN ban cu (khong go app) de giu quyen ADB.
- Cap quyen 1 lan: pm grant com.gemini.guard android.permission.WRITE_SECURE_SETTINGS
- Moi: nut "Tat -> bat lai Google" + tu chay sau khoi dong may (nhu app Gemini Restore).
  Bat "Tu khoi dong" cho app trong HyperOS de nhan duoc tin hieu khoi dong.
