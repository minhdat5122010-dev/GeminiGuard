package com.gemini.guard

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.SharedPreferences
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Nhan biet Mi AI / XiaoAi vua bat len (giu nut nguon...) -> tu goi Gemini de len tren.
 * Ghi lai cac package vua thay de ban biet ten goi dung cua Mi AI tren may.
 */
class MiAiWatcher : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastFire = 0L
    private var lastGoogleEvt = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (pkg == GOOGLE_PKG) { onGoogleWindow(e); return }
        val pr = Restorer.prefs(this)
        if (!pr.getBoolean("mi_on", false)) return

        remember(pkg, "$pkg  ${e.className}")

        val targets = (pr.getString("mi_pkgs", DEFAULT_PKGS) ?: DEFAULT_PKGS)
            .split(",", ";", " ", "\n").map { it.trim() }.filter { it.isNotEmpty() }
        if (pkg !in targets) return

        val cls = e.className?.toString() ?: ""

        // Che do hoc: ghi lai ten cua so, khong goi Gemini
        val mode = pr.getString("learn_mode", "") ?: ""
        if (mode.isNotEmpty()) {
            if (SystemClock.elapsedRealtime() <= pr.getLong("learn_until", 0L)) { learn(pr, mode, cls); return }
            pr.edit().remove("learn_mode").apply()
        }

        // Loc theo ten cua so: chi lop phu giong noi moi goi Gemini, mo app / dich man hinh thi bo qua
        val exc = pr.getString("mi_exc", "") ?: ""
        val inc = pr.getString("mi_inc", "") ?: ""
        if (exc.isNotBlank() && matches(exc, cls)) return
        if (inc.isNotBlank() && !matches(inc, cls)) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastFire < 4000) return   // chong lap
        lastFire = now

        val delay = pr.getInt("mi_delay", 350).toLong()
        val doTap = pr.getBoolean("mi_swipe", false)

        // Dong Mi AI truoc (Back)
        if (pr.getBoolean("mi_back", true)) performGlobalAction(GLOBAL_ACTION_BACK)

        if (doTap) {
            // Cho lop phu Mi AI hien xong (dang animation thi cham se bi bo qua), roi moi cham
            handler.postDelayed({ tapOutside(pkg, 0) }, TAP_WAIT)
            // Neu lop phu van con thi cham lai bang toa do cai dat
            handler.postDelayed({ if (miWindowBounds(pkg) != null) tapOutside(pkg, 1) }, TAP_WAIT + 500)
            // Cho Mi AI tat han (toi da MAX_WAIT) roi moi goi Gemini
            val t0 = SystemClock.elapsedRealtime()
            val poll = object : Runnable {
                override fun run() {
                    val gone = miWindowBounds(pkg) == null
                    val late = SystemClock.elapsedRealtime() - t0 > MAX_WAIT
                    if ((gone && SystemClock.elapsedRealtime() - t0 > TAP_WAIT + 150) || late) callGemini(pkg)
                    else handler.postDelayed(this, 100)
                }
            }
            handler.postDelayed(poll, maxOf(delay, TAP_WAIT + 200))
        } else {
            handler.postDelayed({ callGemini(pkg) }, delay)
        }
    }

    private fun callGemini(pkg: String) {
        // Thu dung tien trinh Mi AI (co the khong tac dung neu la tien trinh he thong)
        try { (getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager).killBackgroundProcesses(pkg) } catch (_: Throwable) {}
        Restorer.ensure(this)
        val err = GeminiCall.show()
        if (err == null) GeminiSound.play(this)
        else Toast.makeText(this, "Không gọi được Gemini: $err", Toast.LENGTH_LONG).show()
    }

    /** Khung cua so cua package dang hien tren man hinh (null = khong con). Can canRetrieveWindowContent. */
    private fun miWindowBounds(pkg: String): android.graphics.Rect? {
        return try {
            var best: android.graphics.Rect? = null
            for (w in windows) {
                val root = w.root ?: continue
                if (root.packageName?.toString() == pkg) {
                    val r = android.graphics.Rect(); w.getBoundsInScreen(r)
                    if (best == null || r.width() * r.height() > best.width() * best.height()) best = r
                }
            }
            best
        } catch (_: Throwable) { null }
    }

    /** Cua so cua app Google (Gemini overlay) vua hien -> phat am thanh (ca khi giu nut nguon / goi giong noi). */
    private fun onGoogleWindow(e: AccessibilityEvent) {
        val pr = Restorer.prefs(this)
        val now = SystemClock.elapsedRealtime()
        val cls = e.className?.toString() ?: ""
        val old = (pr.getString("gseen", "") ?: "").split("\n").filter { it.isNotBlank() && it != cls }
        pr.edit().putString("gseen", (listOf(cls) + old).take(8).joinToString("\n")).apply()

        val filter = pr.getString("snd_cls", "")?.trim().orEmpty()
        val gap = pr.getInt("snd_gap_s", 3) * 1000L
        val fresh = now - lastGoogleEvt > gap      // phien moi, khong phai su kien tiep noi
        lastGoogleEvt = now
        if (fresh && pr.getBoolean("snd_on", false) &&
            (filter.isEmpty() || cls.contains(filter, ignoreCase = true)) &&
            now - GeminiSound.lastPlay > gap) GeminiSound.play(this, 0)
    }

    private fun matches(list: String, cls: String): Boolean =
        list.split(",", "\n", ";").map { it.trim() }.filter { it.isNotEmpty() }
            .any { cls.contains(it, ignoreCase = true) }

    private fun learn(pr: SharedPreferences, mode: String, cls: String) {
        if (cls.isEmpty()) return
        val key = if (mode == "inc") "mi_inc" else "mi_exc"
        val cur = (pr.getString(key, "") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (cls !in cur) pr.edit().putString(key, (cur + cls).joinToString(",")).apply()
        if (mode == "inc") pr.edit().remove("learn_mode").apply()   // giong noi: chi can cua so dau tien
        Toast.makeText(this, "Đã học (${if (mode == "inc") "giọng nói" else "loại trừ"}): $cls", Toast.LENGTH_SHORT).show()
    }

    private fun remember(pkg: String, line: String) {
        if (pkg in IGNORE) return
        val pr = Restorer.prefs(this)
        val old = (pr.getString("seen", "") ?: "").split("\n").filter { it.isNotBlank() && it != line }
        pr.edit().putString("seen", (listOf(line) + old).take(10).joinToString("\n")).apply()
    }

    /**
     * Cham vao cho trong de dong thanh Mi AI.
     * attempt 0: neu lop phu chi chiem 1 phan man hinh -> cham ngay NGOAI khung lop phu.
     * Neu lop phu phu kin man hinh (hoac khong doc duoc) -> dung toa do % cai dat.
     */
    private fun tapOutside(pkg: String, attempt: Int) {
        try {
            val pr = Restorer.prefs(this)
            val dm = resources.displayMetrics
            val W = dm.widthPixels.toFloat(); val H = dm.heightPixels.toFloat()
            var x = W * pr.getInt("mi_tx", 8) / 100f
            var y = H * pr.getInt("mi_ty", 10) / 100f
            val r = if (attempt == 0) miWindowBounds(pkg) else null
            if (r != null && r.height() < H * 0.9f) {
                x = W / 2f
                y = if (r.top > H * 0.3f) r.top / 2f          // thanh nam duoi -> cham phia tren
                    else (r.bottom + H) / 2f                  // thanh nam tren -> cham phia duoi
            }
            val path = Path().apply { moveTo(x, y) }
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build()
            dispatchGesture(g, null, null)
        } catch (_: Throwable) {}
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        GeminiSound.warm(this)
    }

    override fun onInterrupt() {}

    companion object {
        private const val TAP_WAIT = 150L
        private const val MAX_WAIT = 1800L
        const val DEFAULT_PKGS = "com.miui.voiceassist"
        const val GOOGLE_PKG = "com.google.android.googlequicksearchbox"
        private val IGNORE = setOf(
            "com.android.systemui", "com.miui.home", "com.mi.android.globallauncher",
            "com.google.android.googlequicksearchbox", "com.android.settings", "android"
        )
    }
}
