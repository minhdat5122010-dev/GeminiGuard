package com.gemini.guard

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Restorer {
    const val GOOGLE_ASSIST =
        "com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService"
    private val SECURE_KEYS = listOf("assistant", "voice_interaction_service")
    private const val POWER_KEY = "power_button_long_press"
    private const val POWER_VALUE = 5

    const val ACC_KEY = "enabled_accessibility_services"

    private fun enabledList(r: android.content.ContentResolver): List<String> =
        (Settings.Secure.getString(r, ACC_KEY) ?: "").split(":").filter { it.isNotBlank() }

    fun accessibilityOn(c: Context): Boolean {
        val cn = ComponentName(c, MiAiWatcher::class.java)
        return enabledList(c.contentResolver).any { ComponentName.unflattenFromString(it) == cn } &&
            Settings.Secure.getInt(c.contentResolver, "accessibility_enabled", 0) == 1
    }

    fun prefs(c: Context) = c.getSharedPreferences("guard", Context.MODE_PRIVATE)

    fun hasPermission(c: Context) =
        c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    /** Ghi lại giá trị đúng nếu bị đổi. Trả về mô tả những gì đã sửa. */
    fun ensure(c: Context): List<String> {
        val changes = mutableListOf<String>()
        if (!hasPermission(c)) return changes
        if (cycling) return changes   // dang tat -> bat lai Google, dung can thiep
        val r = c.contentResolver
        try {
            for (k in SECURE_KEYS) {
                val cur = Settings.Secure.getString(r, k)
                if (cur != GOOGLE_ASSIST) {
                    Settings.Secure.putString(r, k, GOOGLE_ASSIST)
                    changes += "$k: [${cur ?: "null"}] -> Google"
                }
            }
            val p = Settings.Global.getInt(r, POWER_KEY, -1)
            if (p != POWER_VALUE) {
                Settings.Global.putInt(r, POWER_KEY, POWER_VALUE)
                changes += "$POWER_KEY: [$p] -> $POWER_VALUE"
            }
            if (prefs(c).getBoolean("mi_on", false) && !accessibilityOn(c)) {
                val cn = ComponentName(c, MiAiWatcher::class.java)
                val list = enabledList(r).filter { ComponentName.unflattenFromString(it) != cn }
                Settings.Secure.putString(r, ACC_KEY, (list + cn.flattenToString()).joinToString(":"))
                Settings.Secure.putInt(r, "accessibility_enabled", 1)
                changes += "tro nang MiAiWatcher: TAT -> BAT"
            }
        } catch (e: SecurityException) {
            changes += "Lỗi quyền: ${e.message}"
        }
        if (changes.isNotEmpty()) log(c, changes.joinToString("; "))
        return changes
    }

    // ---------- Tat -> bat lai Google (giong app Gemini Restore) ----------
    @Volatile var cycling = false
    private val cycleBusy = java.util.concurrent.atomic.AtomicBoolean(false)

    /**
     * Ngat tro ly (de trong), cho, bat lai Google va dat nut nguon = 5, roi doc lai de kiem tra.
     * Co Thread.sleep nen PHAI chay tren luong nen. Tra ve mo ta ket qua.
     */
    fun cycle(c: Context): String {
        if (!hasPermission(c)) return "Chưa cấp quyền WRITE_SECURE_SETTINGS. Hãy cấp bằng ADB trước."
        if (!cycleBusy.compareAndSet(false, true)) return "Đang chạy, chờ vài giây rồi thử lại."
        cycling = true
        val r = c.contentResolver
        val oldAssistant = Settings.Secure.getString(r, "assistant")
        val oldService = Settings.Secure.getString(r, "voice_interaction_service")
        val oldPower = Settings.Global.getString(r, POWER_KEY)
        val msg = try {
            runCycle(c)
        } catch (e: Throwable) {
            try {
                Settings.Secure.putString(r, "voice_interaction_service", oldService)
                Settings.Secure.putString(r, "assistant", oldAssistant)
                Settings.Global.putString(r, POWER_KEY, oldPower)
            } catch (_: Throwable) {}
            "Không hoàn tất: ${e.javaClass.simpleName}: ${e.message}. Đã trả về giá trị cũ."
        } finally {
            cycling = false
            cycleBusy.set(false)
        }
        val t = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(Date())
        prefs(c).edit().putString("cycle_last", "$t  $msg").apply()
        log(c, "tắt→bật Google: $msg")
        return msg
    }

    private fun runCycle(c: Context): String {
        val r = c.contentResolver
        val cn = ComponentName.unflattenFromString(GOOGLE_ASSIST)!!
        val info = try { c.packageManager.getServiceInfo(cn, 0) } catch (_: Exception) { null }
        if (info == null || !info.enabled) return "Không tìm thấy dịch vụ trợ lý Google đang bật; chưa thay đổi gì."

        val offMs = prefs(c).getInt("cycle_off_ms", 1500).toLong()
        Settings.Secure.putString(r, "voice_interaction_service", "")
        Settings.Secure.putString(r, "assistant", "")
        Thread.sleep(offMs)

        Settings.Secure.putString(r, "voice_interaction_service", GOOGLE_ASSIST)
        Settings.Secure.putString(r, "assistant", GOOGLE_ASSIST)
        Settings.Global.putString(r, POWER_KEY, POWER_VALUE.toString())
        Thread.sleep(1000)

        val ok = Settings.Secure.getString(r, "assistant") == GOOGLE_ASSIST &&
            Settings.Secure.getString(r, "voice_interaction_service") == GOOGLE_ASSIST &&
            Settings.Global.getString(r, POWER_KEY) == POWER_VALUE.toString()
        return if (ok) "Đã tắt → bật lại Google; đọc lại đúng 3 giá trị. Hãy thử giữ nút nguồn."
        else "Đã chạy nhưng HyperOS chưa giữ đúng giá trị (hệ thống có thể đã tự đổi lại). Thử bấm lại."
    }

    /** Goi tu BootReceiver (luong nen). Moi lan khoi dong may chi chay 1 lan. */
    fun cycleOnBoot(c: Context) {
        val pr = prefs(c)
        val bc = Settings.Global.getInt(c.contentResolver, "boot_count", -1)
        if (bc != -1 && bc == pr.getInt("last_cycle_boot", -2)) return
        pr.edit().putInt("last_cycle_boot", bc).apply()
        val d = pr.getInt("cycle_boot_delay_s", 0)
        if (d > 0) Thread.sleep(d * 1000L)
        cycle(c)
    }

    private fun log(c: Context, msg: String) {
        val t = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(Date())
        val old = prefs(c).getString("log", "") ?: ""
        val lines = (listOf("$t  $msg") + old.split("\n").filter { it.isNotBlank() }).take(10)
        prefs(c).edit().putString("log", lines.joinToString("\n")).apply()
    }

    fun status(c: Context): String {
        val r = c.contentResolver
        val sb = StringBuilder()
        sb.append("Quyền WRITE_SECURE_SETTINGS: ").append(if (hasPermission(c)) "OK" else "CHƯA CẤP").append("\n")
        for (k in SECURE_KEYS) {
            val v = Settings.Secure.getString(r, k)
            sb.append(k).append(": ").append(if (v == GOOGLE_ASSIST) "Google OK" else "[${v ?: "trống"}] SAI").append("\n")
        }
        sb.append(POWER_KEY).append(": ").append(Settings.Global.getInt(r, POWER_KEY, -1)).append("\n")
        sb.append("Trợ năng MiAiWatcher: ").append(if (accessibilityOn(c)) "BẬT" else "TẮT").append("\n")
        sb.append("Tắt→bật Google gần nhất: ").append(prefs(c).getString("cycle_last", "")?.ifBlank { "(chưa chạy)" } ?: "(chưa chạy)").append("\n")
        sb.append("\nNhật ký tự sửa (mới nhất trước):\n")
        sb.append(prefs(c).getString("log", "")?.ifBlank { "(chưa có)" } ?: "(chưa có)")
        return sb.toString()
    }

    /** Liet ke cac cai dat he thong lien quan tro ly / nut nguon de tim cong tac tat Mi AI. */
    fun dumpRelated(c: Context): String {
        val re = Regex("power|xiaoai|voice|assist|long_press|speech|aivoice|ai_key", RegexOption.IGNORE_CASE)
        val noise = Regex("layoutDescriptor|white_list|power_center|low_power|POWER_SAVE|perf_|powerkeep|volume_|power_supersave|superpower|lower_power", RegexOption.IGNORE_CASE)
        val sb = StringBuilder()
        val tables = listOf(
            "global" to Settings.Global.CONTENT_URI,
            "secure" to Settings.Secure.CONTENT_URI,
            "system" to Settings.System.CONTENT_URI
        )
        for ((n, u) in tables) {
            try {
                c.contentResolver.query(u, arrayOf("name", "value"), null, null, null)?.use { cur ->
                    while (cur.moveToNext()) {
                        val k = cur.getString(0) ?: continue
                        if (re.containsMatchIn(k) && !noise.containsMatchIn(k)) sb.append(n).append(": ").append(k).append(" = ").append(cur.getString(1)).append("\n")
                    }
                }
            } catch (e: Throwable) { sb.append(n).append(": lỗi ").append(e.message).append("\n") }
        }
        return sb.toString().ifBlank { "(không tìm thấy)" }.take(12000)
    }
}
