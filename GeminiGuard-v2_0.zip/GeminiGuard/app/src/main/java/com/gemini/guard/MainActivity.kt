package com.gemini.guard

import android.app.Activity
import android.app.AlertDialog
import android.view.Gravity
import android.widget.ImageView
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

private val BG = 0xFFF1F3F8.toInt()
private val CARD = Color.WHITE
private val INK = 0xFF1B1D22.toInt()
private val MUTED = 0xFF6B7280.toInt()
private val ACCENT = 0xFF3B6FE0.toInt()
private val TONAL = 0xFFE6EDFC.toInt()
private val GOOD = 0xFF1E8E3E.toInt()
private val BAD = 0xFFC62828.toInt()
private val FIELD = 0xFFF4F5F9.toInt()
private val LINE = 0xFFD9DCE5.toInt()

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var ctsPkg: EditText
    private lateinit var miPkgs: EditText
    private lateinit var miInc: EditText
    private lateinit var miExc: EditText
    private lateinit var trPkg: EditText
    private lateinit var trTxt: EditText
    private lateinit var sndCls: EditText
    private lateinit var warnCard: LinearLayout
    private lateinit var stateBox: LinearLayout

    private fun prefs() = Restorer.prefs(this)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun pushService() {
        Restorer.ensure(this)
        if (prefs().getBoolean("enabled", true) || prefs().getBoolean("bar", false))
            startForegroundService(Intent(this, GuardService::class.java))
        else stopService(Intent(this, GuardService::class.java))
    }

    // ---------- Hỗ trợ ----------
    private fun openUrl(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { Toast.makeText(this, "Không mở được liên kết: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    /** Luu anh QR vao thu vien (Pictures/GeminiGuard) de quet bang ung dung ngan hang tren cung dien thoai. */
    private fun saveQr() {
        try {
            if (android.os.Build.VERSION.SDK_INT < 29) {
                Toast.makeText(this, "Android thấp: hãy chụp màn hình mã QR rồi quét từ thư viện", Toast.LENGTH_LONG).show(); return
            }
            val bmp = android.graphics.BitmapFactory.decodeResource(resources, R.drawable.qr_donate)
            val cv = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "GeminiGuard_QR_mi_tom.png")
                put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, android.os.Environment.DIRECTORY_PICTURES + "/GeminiGuard")
            }
            val uri = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                ?: throw IllegalStateException("không tạo được tệp")
            contentResolver.openOutputStream(uri)?.use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            Toast.makeText(this, "Đã lưu ảnh QR vào thư viện (Pictures/GeminiGuard)", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Không lưu được ảnh: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun showSupport() {
        val url = "https://www.facebook.com/datbeans512/"
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        body.addView(label("Cần hỗ trợ cài đặt hoặc gặp lỗi? Liên hệ admin Gemini Guard qua Facebook để được trợ giúp.", 14f, INK))
        body.addView(label("Facebook admin", 13f, MUTED, true).apply { setPadding(0, dp(14), 0, 0) })
        body.addView(TextView(this).apply {
            text = url; textSize = 14f; setTextColor(ACCENT)
            paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
            setPadding(0, dp(4), 0, dp(4))
            setOnClickListener { openUrl(url) }
        })
        body.addView(label(
            "Khi nhờ hỗ trợ, bạn nên gửi kèm ảnh chụp màn hình và nút \"Sao chép trạng thái\" " +
                "(mục Công cụ và chẩn đoán).",
            12f, MUTED).apply { setPadding(0, dp(12), 0, 0) })

        // Ung ho admin
        body.addView(View(this).apply { setBackgroundColor(0x1F000000) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)).apply { topMargin = dp(18) })
        body.addView(label("Hỗ trợ admin gói mì tôm", 16f, INK, true).apply { setPadding(0, dp(16), 0, 0) })
        body.addView(label("Nếu thấy app hữu ích, bạn có thể mời admin một gói mì tôm bằng cách quét mã QR bên dưới (mọi ứng dụng ngân hàng và ví đều quét được). Không bắt buộc nhé.", 13f, MUTED)
            .apply { setPadding(0, dp(6), 0, dp(10)) })
        body.addView(ImageView(this).apply {
            setImageResource(R.drawable.qr_donate)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        btn(body, "Lưu ảnh QR vào thư viện", top = 8) { saveQr() }
        body.addView(View(this), LinearLayout.LayoutParams(1, dp(8)))

        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
            .setTitle("Hỗ trợ")
            .setView(ScrollView(this).apply { addView(body) })
            .setPositiveButton("Mở Facebook") { _, _ -> openUrl(url) }
            .setNeutralButton("Sao chép link") { _, _ -> copy("facebook", url, "Đã sao chép liên kết") }
            .setNegativeButton("Đóng", null)
            .show()
    }

    // ---------- Thành phần giao diện ----------
    private fun shape(color: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun lp(top: Int = 0) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun card(root: LinearLayout, title: String, desc: String? = null): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(CARD, 18)
            setPadding(dp(18), dp(16), dp(18), dp(18))
            elevation = dp(1).toFloat()
        }
        c.addView(label(title, 17f, INK, true))
        if (desc != null) c.addView(label(desc, 13f, MUTED).apply { setPadding(0, dp(4), 0, 0) })
        root.addView(c, lp(14))
        return c
    }

    private fun sw(p: LinearLayout, text: String, hint: String?, key: String, def: Boolean) {
        val s = Switch(this).apply {
            this.text = text; textSize = 15f; setTextColor(INK)
            isChecked = prefs().getBoolean(key, def)
            setOnCheckedChangeListener { _, on -> prefs().edit().putBoolean(key, on).apply(); pushService() }
        }
        p.addView(s, lp(14))
        if (hint != null) p.addView(label(hint, 12f, MUTED).apply { setPadding(0, dp(2), 0, 0) }, lp(0))
    }

    /** Dong chon hanh dong cho cu chi (hop thoai chon 1). */
    private fun choice(p: LinearLayout, text: String, key: String) {
        val opts = BarOverlay.ACTIONS
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10), 0, dp(10))
        }
        row.addView(label(text, 14f, INK), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        fun labelOf(v: String) = opts.firstOrNull { it.first == v }?.second ?: v
        val value = label(labelOf(BarOverlay.currentAction(prefs(), key)), 14f, ACCENT, true)
        row.addView(value)
        row.setOnClickListener {
            val cur = BarOverlay.currentAction(prefs(), key)
            val idx = opts.indexOfFirst { it.first == cur }.coerceAtLeast(0)
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Light_Dialog_Alert)
                .setTitle(text)
                .setSingleChoiceItems(opts.map { it.second }.toTypedArray(), idx) { d, which ->
                    prefs().edit().putString(key, opts[which].first).apply()
                    value.text = opts[which].second
                    d.dismiss()
                }
                .setNegativeButton("Hủy", null)
                .show()
        }
        p.addView(row)
    }

    private fun seek(p: LinearLayout, text: String, unit: String, key: String, max: Int, def: Int) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(label(text, 14f, INK), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val v = label("${prefs().getInt(key, def)}$unit", 14f, ACCENT, true)
        row.addView(v)
        p.addView(row, lp(16))
        val sb = SeekBar(this).apply {
            this.max = max; progress = prefs().getInt(key, def)
            progressTintList = ColorStateList.valueOf(ACCENT)
            thumbTintList = ColorStateList.valueOf(ACCENT)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, pr: Int, u: Boolean) { v.text = "$pr$unit" }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {
                    prefs().edit().putInt(key, s.progress).apply(); pushService()
                }
            })
        }
        p.addView(sb, lp(0))
    }

    private fun btn(p: LinearLayout, text: String, primary: Boolean = false, top: Int = 12, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = text; isAllCaps = false; textSize = 14f
            setTextColor(if (primary) Color.WHITE else ACCENT)
            stateListAnimator = null; minimumHeight = dp(46)
            background = RippleDrawable(
                ColorStateList.valueOf(0x33000000),
                shape(if (primary) ACCENT else TONAL, 12), shape(Color.WHITE, 12)
            )
            setOnClickListener { action(); refresh() }
        }
        p.addView(b, lp(top))
    }

    private fun field(p: LinearLayout, title: String, hint: String, value: String): EditText {
        p.addView(label(title, 12f, MUTED), lp(16))
        val e = EditText(this).apply {
            this.hint = hint; setText(value); textSize = 14f; setTextColor(INK)
            setSingleLine(true)
            background = shape(FIELD, 12, LINE)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        p.addView(e, lp(6))
        return e
    }

    private fun stateRow(ok: Boolean, name: String, okText: String, badText: String): TextView {
        val color = if (ok) GOOD else BAD
        val sb = SpannableStringBuilder("●  ")
        sb.setSpan(ForegroundColorSpan(color), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sb.append(name).append(":  ")
        val start = sb.length
        sb.append(if (ok) okText else badText)
        sb.setSpan(ForegroundColorSpan(color), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        return TextView(this).apply { text = sb; textSize = 14f; setTextColor(INK); setPadding(0, dp(3), 0, dp(3)) }
    }

    private fun copy(name: String, value: CharSequence, toast: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(name, value))
        Toast.makeText(this, toast, Toast.LENGTH_SHORT).show()
    }

    private fun openAppSettings() =
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))

    private fun bindPref(e: EditText, key: String) {
        e.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                prefs().edit().putString(key, s?.toString()?.trim() ?: "").apply()
            }
        })
    }

    private fun learnMode(mode: String) {
        prefs().edit().putString("learn_mode", mode)
            .putLong("learn_until", android.os.SystemClock.elapsedRealtime() + 20000L).apply()
        Toast.makeText(this,
            if (mode == "inc") "Hãy gọi Mi AI bằng giọng nói ngay (trong 20 giây), chỉ cần nói câu gọi."
            else "Hãy mở app Mi AI và bật dịch màn hình ngay (trong 20 giây).",
            Toast.LENGTH_LONG).show()
    }

    private fun openAutostart() {
        try {
            startActivity(Intent().setComponent(ComponentName(
                "com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")))
        } catch (_: Exception) {
            openAppSettings()
            Toast.makeText(this, "Tìm Tự khởi động / Autostart rồi bật Gemini Guard.", Toast.LENGTH_LONG).show()
        }
    }

    // ---------- Màn hình chính ----------
    @Suppress("DEPRECATION")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs().edit().remove("evlog").remove("ev_log").apply()   // don nhat ky su kien cu (tinh nang da go)
        if (android.os.Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        window.statusBarColor = BG
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(22), dp(16), dp(36))
        }
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "?" }

        // Tiêu đề
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.logo)
        }
        head.addView(logo, LinearLayout.LayoutParams(dp(42), dp(42)).apply { rightMargin = dp(10) })
        head.addView(label("Gemini Guard", 26f, INK, true))
        head.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        head.addView(TextView(this).apply {
            text = "Hỗ trợ"; textSize = 14f; setTextColor(ACCENT); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = shape(TONAL, 20)
            setPadding(dp(16), dp(8), dp(16), dp(8))
            setOnClickListener { showSupport() }
        })
        root.addView(head, lp(0))
        root.addView(label("Giữ Gemini luôn là trợ lý mặc định · phiên bản $ver", 13f, MUTED), lp(2))

        // Cảnh báo thiếu quyền
        warnCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(0xFFFDECEA.toInt(), 18, 0xFFF3B9B3.toInt())
            setPadding(dp(18), dp(16), dp(18), dp(18))
        }
        warnCard.addView(label("Chưa cấp quyền ghi cài đặt bảo mật", 16f, BAD, true))
        warnCard.addView(label(
            "Thiếu quyền WRITE_SECURE_SETTINGS nên app không giữ được Google làm trợ lý " +
                "(máy sẽ hiện bảng “Complete action using” và mở app Google). Hãy cấp bằng ADB. " +
                "Khi cập nhật, cài đè lên bản cũ và đừng gỡ cài đặt, vì gỡ sẽ mất quyền.",
            13f, INK).apply { setPadding(0, dp(6), 0, 0) })
        btn(warnCard, "Sao chép lệnh ADB cấp quyền", primary = true) {
            copy("adb", "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS", "Đã sao chép lệnh ADB")
        }
        root.addView(warnCard, lp(14))

        // Trạng thái nhanh
        val st = card(root, "Trạng thái")
        stateBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        st.addView(stateBox, lp(8))

        // 1. Giữ Gemini
        val c1 = card(root, "Giữ Gemini làm trợ lý",
            "Canh các cài đặt hệ thống, nếu HyperOS xóa hoặc đổi sang Mi AI thì tự ghi lại Google.")
        sw(c1, "Canh nền và tự khôi phục Google", null, "enabled", true)
        btn(c1, "Khôi phục ngay", primary = true) {
            val ch = Restorer.ensure(this)
            Toast.makeText(this, if (ch.isEmpty()) "Mọi thứ đã đúng" else "Đã sửa ${ch.size} mục", Toast.LENGTH_SHORT).show()
        }

        btn(c1, "Restart Google", top = 8) {
            Toast.makeText(this, "Đang tắt → bật lại, giữ app mở vài giây…", Toast.LENGTH_SHORT).show()
            Thread {
                val res = Restorer.cycle(this)
                runOnUiThread { Toast.makeText(this, res, Toast.LENGTH_LONG).show(); refresh() }
            }.start()
        }
        sw(c1, "Tự tắt → bật lại Google sau khi khởi động máy",
            "Để giữ nút nguồn gọi Google thay vì Mi AI sau mỗi lần khởi động. Cần bật Tự khởi động cho app.",
            "cycle_boot", true)
        seek(c1, "Đợi sau khi máy khởi động xong", " giây", "cycle_boot_delay_s", 30, 0)
        btn(c1, "Cho phép tự khởi động trên HyperOS", top = 8) { openAutostart() }

        // 2. Thanh điều hướng AI
        val c2 = card(root, "Thanh điều hướng AI",
            "Thanh nhỏ nổi ở đáy màn hình. Chọn việc cho từng cử chỉ bên dưới.")
        sw(c2, "Bật thanh điều hướng AI", null, "bar", false)
        btn(c2, "Cấp quyền hiển thị trên ứng dụng khác") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        ctsPkg = field(c2, "Tên gói MiCTS", "com.parallelc.micts", prefs().getString("cts_pkg", "com.parallelc.micts") ?: "")
        choice(c2, "Chạm đúp", "bar_dt")
        choice(c2, "Giữ", "bar_lp")
        trPkg = field(c2, "Dịch màn hình: tên gói app dịch", "com.xiaomi.aiasst.vision", prefs().getString("tr_pkg", BarOverlay.TR_PKG) ?: "")
        bindPref(trPkg, "tr_pkg")
        trTxt = field(c2, "Dịch màn hình: chữ trên thẻ (phân cách bằng dấu phẩy)", BarOverlay.TR_TEXT, prefs().getString("tr_text", BarOverlay.TR_TEXT) ?: "")
        bindPref(trTxt, "tr_text")
        seek(c2, "Chiều rộng", "%", "bar_w", 100, 40)
        seek(c2, "Chiều cao", " dp", "bar_h", 60, 20)
        seek(c2, "Cách đáy", " dp", "bar_y", 60, 0)
        seek(c2, "Độ đậm (0 = vô hình)", "%", "bar_a", 100, 30)

        // 3. Mi AI
        val c3 = card(root, "Gọi Gemini khi Mi AI bật lên",
            "Khi phát hiện Mi AI (giữ nút nguồn, gọi giọng nói…), app đóng nó và gọi Gemini lên thay thế. Cần bật Trợ năng cho Gemini Guard.")
        sw(c3, "Tự gọi Gemini khi Mi AI bật lên", null, "mi_on", false)
        sw(c3, "Bấm Back để đóng Mi AI", "Thực hiện trước khi gọi Gemini.", "mi_back", true)
        sw(c3, "Chạm vào chỗ trống để đóng thanh Mi AI", "Dùng khi Back không đóng được.", "mi_swipe", false)
        seek(c3, "Vị trí chạm – ngang", "%", "mi_tx", 100, 8)
        seek(c3, "Vị trí chạm – dọc", "%", "mi_ty", 100, 10)
        seek(c3, "Độ trễ trước khi gọi Gemini", " ms", "mi_delay", 1500, 350)
        miPkgs = field(c3, "Tên gói Mi AI (cách nhau bằng dấu phẩy)", "com.miui.voiceassist",
            prefs().getString("mi_pkgs", MiAiWatcher.DEFAULT_PKGS) ?: "")
        miInc = field(c3, "Chỉ gọi Gemini khi cửa sổ Mi AI là (để trống = mọi cửa sổ)", "Để trống = mọi cửa sổ", prefs().getString("mi_inc", MiAiWatcher.DEFAULT_INC) ?: "")
        bindPref(miInc, "mi_inc")
        miExc = field(c3, "Bỏ qua khi cửa sổ Mi AI là (mở app, dịch màn hình…)", "Để trống = không bỏ qua cửa sổ nào", prefs().getString("mi_exc", MiAiWatcher.DEFAULT_EXC) ?: "")
        bindPref(miExc, "mi_exc")
        btn(c3, "Đặt lại bộ lọc về mặc định", top = 12) {
            prefs().edit().remove("mi_inc").remove("mi_exc").remove("learn_mode").apply()
            refresh()
        }
        btn(c3, "Mở cài đặt Trợ năng", primary = true) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn(c3, "Cho phép cài đặt bị hạn chế (Android 13+)", top = 8) { openAppSettings() }

        // 4. Âm thanh
        val c4 = card(root, "Hiệu ứng âm thanh và rung",
            "Phát âm thanh / rung nhẹ khi Gemini hiện lên: giữ nút nguồn, gọi giọng nói (qua Mi AI) hoặc dùng thanh. Cần bật Trợ năng để nhận ra khi giữ nút nguồn.")
        sw(c4, "Phát âm thanh khi Gemini hiện lên", null, "snd_on", false)
        seek(c4, "Âm lượng hiệu ứng", "%", "snd_vol", 100, 100)
        seek(c4, "Khuếch đại thêm (0 = tắt)", " dB", "snd_gain", 15, 0)
        seek(c4, "Bỏ qua đầu âm thanh để bớt trễ", " ms", "snd_skip", 600, 0)
        seek(c4, "Chống lặp âm thanh", " giây", "snd_gap_s", 10, 3)
        sndCls = field(c4, "Lọc tên cửa sổ Google (tùy chọn)", "Để trống = mọi cửa sổ", prefs().getString("snd_cls", "") ?: "")
        btn(c4, "Thử âm thanh", primary = true) { GeminiSound.play(this, force = true) }
        sw(c4, "Rung nhẹ khi Gemini hiện lên", "Máy rung ngắn tạo cảm giác cửa sổ bật ra. Dùng chung bộ lọc cửa sổ và chống lặp với âm thanh ở trên.", "vib_on", false)
        seek(c4, "Độ mạnh rung", "%", "vib_str", 100, 60)
        seek(c4, "Thời gian rung", " ms", "vib_ms", 80, 25)
        btn(c4, "Thử rung", top = 8) { Haptic.pop(this, force = true) }

        // 5. Công cụ
        val c5 = card(root, "Công cụ và chẩn đoán")
        btn(c5, "Cài đặt pin / tự khởi động của app", top = 14) { openAppSettings() }
        btn(c5, "Sao chép cài đặt liên quan Mi AI / nút nguồn", top = 8) {
            copy("settings", Restorer.dumpRelated(this), "Đã sao chép – dán vào chat để gửi cho Claude")
        }
        btn(c5, "Sao chép trạng thái", top = 8) { copy("status", status.text, "Đã sao chép") }
        status = TextView(this).apply {
            textSize = 12f; setTextColor(MUTED); typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            background = shape(FIELD, 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        c5.addView(status, lp(14))

        root.addView(label("Gemini Guard v$ver · by Đỗ Đạt - Yume. System", 12f, MUTED).apply { gravity = android.view.Gravity.CENTER },
            lp(22))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        pushService()
    }

    override fun onResume() { super.onResume(); refresh(); pushService() }

    override fun onPause() {
        super.onPause()
        val t = ctsPkg.text.toString().trim()
        if (t.isNotEmpty()) prefs().edit().putString("cts_pkg", t).apply()
        prefs().edit().putString("snd_cls", sndCls.text.toString().trim()).apply()
        val m = miPkgs.text.toString().trim()
        if (m.isNotEmpty()) prefs().edit().putString("mi_pkgs", m).apply()
        pushService()
    }

    private fun refresh() {
        for ((e, k) in listOf(miInc to "mi_inc", miExc to "mi_exc")) {
            val v = prefs().getString(k, if (k == "mi_inc") MiAiWatcher.DEFAULT_INC else MiAiWatcher.DEFAULT_EXC) ?: ""
            if (e.text.toString().trim() != v) e.setText(v)
        }
        val hasPerm = Restorer.hasPermission(this)
        warnCard.visibility = if (hasPerm) View.GONE else View.VISIBLE

        val r = contentResolver
        val googleOk = Settings.Secure.getString(r, "assistant") == Restorer.GOOGLE_ASSIST &&
            Settings.Secure.getString(r, "voice_interaction_service") == Restorer.GOOGLE_ASSIST
        val pkg = prefs().getString("cts_pkg", "com.parallelc.micts") ?: ""
        val cts = packageManager.getLaunchIntentForPackage(pkg) != null

        stateBox.removeAllViews()
        stateBox.addView(stateRow(hasPerm, "Quyền ghi cài đặt bảo mật", "Đã cấp", "Chưa cấp"))
        stateBox.addView(stateRow(googleOk, "Trợ lý mặc định", "Google", "Chưa đúng"))
        stateBox.addView(stateRow(Settings.canDrawOverlays(this), "Hiển thị trên ứng dụng khác", "Đã cấp", "Chưa cấp"))
        stateBox.addView(stateRow(Restorer.accessibilityOn(this), "Trợ năng (theo dõi Mi AI)", "Đang bật", "Đang tắt"))
        stateBox.addView(stateRow(cts, "MiCTS", "Đã cài", "Chưa cài"))

        status.text = Restorer.status(this) +
            "\n\nCửa sổ Google vừa thấy (mới nhất trước):\n" +
            (prefs().getString("gseen", "")?.ifBlank { "(chưa có)" } ?: "") +
            "\n\nỨng dụng vừa thấy (để tìm tên gói Mi AI):\n" +
            (prefs().getString("seen", "")?.ifBlank { "(chưa có – bật Trợ năng rồi gọi Mi AI)" } ?: "")
    }
}
