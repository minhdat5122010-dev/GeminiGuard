package com.gemini.guard

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.IBinder
import android.os.SystemClock
import org.lsposed.hiddenapibypass.HiddenApiBypass
import android.provider.Settings
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast

class BarOverlay(private val ctx: Context) {
    private val wm = ctx.getSystemService(WindowManager::class.java)
    private var view: View? = null

    fun refresh() {
        val on = Restorer.prefs(ctx).getBoolean("bar", false)
        if (on && Settings.canDrawOverlays(ctx)) show() else hide()
    }

    private fun show() {
        hide()
        val p = Restorer.prefs(ctx)
        val dm = ctx.resources.displayMetrics
        val w = dm.widthPixels * p.getInt("bar_w", 40) / 100
        val h = (dm.density * p.getInt("bar_h", 20)).toInt().coerceAtLeast(8)
        val y = (dm.density * p.getInt("bar_y", 0)).toInt()
        val alpha = p.getInt("bar_a", 30) * 255 / 100

        val v = View(ctx)
        v.background = GradientDrawable().apply {
            cornerRadius = h / 2f
            setColor(Color.argb(alpha, 255, 255, 255))
        }
        val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onLongPress(e: MotionEvent) {
                v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                launchCts()
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                v.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK)
                if (Restorer.prefs(ctx).getBoolean("dt_translate", false)) launchTranslate() else launchAssist()
                return true
            }
        })
        v.setOnTouchListener { _, e -> gd.onTouchEvent(e) }

        val lp = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            this.y = y
        }
        try { wm.addView(v, lp); view = v } catch (e: Exception) {
            Toast.makeText(ctx, "Không hiện được thanh: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    fun hide() {
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
    }

    /** Dam bao assistant/voice_interaction_service dang la Google truoc khi goi. Tra ve true neu vua phai sua. */
    private fun preflight(): Boolean {
        if (!Restorer.hasPermission(ctx)) {
            Toast.makeText(ctx,
                "Chưa cấp WRITE_SECURE_SETTINGS → trợ lý có thể bị sai (hiện bảng chọn). Mở Gemini Guard để lấy lệnh ADB.",
                Toast.LENGTH_LONG).show()
            return false
        }
        return Restorer.ensure(ctx).isNotEmpty()
    }

    private fun launchCts() {
        if (preflight()) {
            // Cho he thong ap dung cai dat roi moi mo MiCTS
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ doLaunchCts() }, 400)
        } else doLaunchCts()
    }

    private fun doLaunchCts() {
        val pkg = Restorer.prefs(ctx).getString("cts_pkg", "com.parallelc.micts") ?: "com.parallelc.micts"
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
        if (i == null) {
            Toast.makeText(ctx, "Chưa cài MiCTS ($pkg)", Toast.LENGTH_LONG).show(); return
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(i) } catch (e: Exception) {
            Toast.makeText(ctx, "Lỗi mở MiCTS: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun launchAssist() {
        preflight()
        val err = GeminiCall.show()
        if (err == null) { GeminiSound.play(ctx); return }
        // Du phong: mo thang app Gemini (neu co), khong dung ACTION_ASSIST vi hien bang chon
        val gem = ctx.packageManager.getLaunchIntentForPackage("com.google.android.apps.bard")
        try {
            if (gem != null) { ctx.startActivity(gem.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); GeminiSound.play(ctx) }
            else Toast.makeText(ctx, "Không gọi được Gemini: $err", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(ctx, "Lỗi: $err", Toast.LENGTH_LONG).show()
        }
    }

    /** Bat AI dich man hinh cua Xiaomi. Uu tien Activity/Service da khai bao, khong co thi mo app theo bieu tuong. */
    private fun launchTranslate() {
        val pr = Restorer.prefs(ctx)
        val pkg = (pr.getString("tr_pkg", "com.xiaomi.aiasst.vision") ?: "").trim()
        val cls = (pr.getString("tr_cls", "") ?: "").trim()
        if (pkg.isEmpty()) { Toast.makeText(ctx, "Chưa nhập tên gói app dịch", Toast.LENGTH_LONG).show(); return }
        try {
            if (cls.isNotEmpty()) {
                val c = android.content.ComponentName(pkg, cls)
                val i = Intent().setComponent(c).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { ctx.startActivity(i) } catch (_: Exception) {
                    // Co the la Service
                    ctx.startService(Intent().setComponent(c))
                }
            } else {
                val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
                if (i == null) { Toast.makeText(ctx, "Không mở được $pkg – hãy nhập tên Activity", Toast.LENGTH_LONG).show(); return }
                ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } catch (e: Exception) {
            Toast.makeText(ctx, "Lỗi mở dịch màn hình: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
