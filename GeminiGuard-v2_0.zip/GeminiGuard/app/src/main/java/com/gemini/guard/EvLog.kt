package com.gemini.guard

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Nhat ky su kien chi tiet (khong chong trung, co gio den mili giay). Cu nhat o tren, moi nhat o cuoi. */
object EvLog {
    private const val KEY = "evlog"
    private const val MAX = 150
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    @Synchronized
    fun add(c: Context, msg: String) {
        val pr = Restorer.prefs(c)
        val lines = (pr.getString(KEY, "") ?: "").split("\n").filter { it.isNotEmpty() }.toMutableList()
        lines.add("${fmt.format(Date())}  $msg")
        val keep = if (lines.size > MAX) lines.subList(lines.size - MAX, lines.size) else lines
        pr.edit().putString(KEY, keep.joinToString("\n")).apply()
    }

    fun get(c: Context): String = Restorer.prefs(c).getString(KEY, "") ?: ""

    fun tail(c: Context, n: Int): String = get(c).split("\n").filter { it.isNotEmpty() }.takeLast(n).joinToString("\n")

    fun clear(c: Context) { Restorer.prefs(c).edit().remove(KEY).apply() }
}
