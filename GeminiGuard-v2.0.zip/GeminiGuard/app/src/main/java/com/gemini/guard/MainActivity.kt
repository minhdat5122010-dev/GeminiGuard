package com.gemini.guard

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var ctsPkg: EditText
    private lateinit var miPkgs: EditText
    private lateinit var sndCls: EditText
    private lateinit var warn: TextView
    private lateinit var warnBtn: Button
    private fun prefs() = Restorer.prefs(this)
    private fun pushService() {
        Restorer.ensure(this)
        if (prefs().getBoolean("enabled", true) || prefs().getBoolean("bar", false))
            startForegroundService(Intent(this, GuardService::class.java))
        else stopService(Intent(this, GuardService::class.java))
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (android.os.Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a(); refresh() } }
        fun sw(t: String, key: String, def: Boolean) = Switch(this).apply {
            text = t; isChecked = prefs().getBoolean(key, def)
            setOnCheckedChangeListener { _, on -> prefs().edit().putBoolean(key, on).apply(); pushService() }
        }
        fun seek(label: String, key: String, max: Int, def: Int): LinearLayout {
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val tv = TextView(this).apply { text = "$label: ${prefs().getInt(key, def)}" }
            val sb = SeekBar(this).apply {
                this.max = max; progress = prefs().getInt(key, def)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { tv.text = "$label: $p" }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {
                        prefs().edit().putInt(key, s.progress).apply(); pushService()
                    }
                })
            }
            box.addView(tv); box.addView(sb); return box
        }

        warn = TextView(this).apply {
            textSize = 14f; setTextColor(0xFFB00020.toInt()); setPadding(0, 0, 0, 20)
            text = "CHUA CAP QUYEN WRITE_SECURE_SETTINGS! Khong co quyen nay app khong giu duoc Google lam tro ly " +
                "(se hien bang chon 'Complete action using' va mo app Google). Cap bang ADB, " +
                "va khi cap nhat app hay cai DE LEN, KHONG go cai dat (go se mat quyen)."
        }
        root.addView(warn)
        warnBtn = btn("Sao chep lenh ADB cap quyen") {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(
                ClipData.newPlainText("adb", "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS"))
            Toast.makeText(this, "Da sao chep lenh ADB", Toast.LENGTH_SHORT).show()
        }
        root.addView(warnBtn)
        root.addView(sw("Canh nen va tu khoi phuc Google", "enabled", true))
        root.addView(btn("Khoi phuc ngay") {
            val ch = Restorer.ensure(this)
            Toast.makeText(this, if (ch.isEmpty()) "Da dung san" else "Da sua ${ch.size} muc", Toast.LENGTH_SHORT).show()
        })

        root.addView(TextView(this).apply { text = "\nTHANH DIEU HUONG AI\nGiu = mo MiCTS (Circle to Search). Cham dup = goi tro ly mac dinh (Gemini)."; textSize = 14f })
        root.addView(sw("Bat thanh dieu huong AI", "bar", false))
        root.addView(btn("Cap quyen hien thi tren ung dung khac") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        ctsPkg = EditText(this).apply {
            hint = "Ten goi MiCTS"
            setText(prefs().getString("cts_pkg", "com.parallelc.micts"))
        }
        root.addView(ctsPkg)
        root.addView(seek("Chieu rong (% man hinh)", "bar_w", 100, 40))
        root.addView(seek("Chieu cao (dp)", "bar_h", 60, 20))
        root.addView(seek("Cach day (dp)", "bar_y", 60, 0))
        root.addView(seek("Do dam (%, 0 = vo hinh)", "bar_a", 100, 30))

        root.addView(TextView(this).apply {
            text = "\nGOI GEMINI KHI MI AI BAT LEN\nKhi phat hien Mi AI (giu nut nguon...) app tu goi Gemini de len tren. Can bat Tro nang cho Gemini Guard."
            textSize = 14f
        })
        root.addView(sw("Tu goi Gemini khi Mi AI bat len", "mi_on", false))
        root.addView(sw("Bam Back de dong Mi AI truoc khi goi Gemini", "mi_back", true))
        root.addView(sw("Cham vao cho trong de dong thanh Mi AI", "mi_swipe", false))
        root.addView(seek("Vi tri cham - ngang (% man hinh)", "mi_tx", 100, 8))
        root.addView(seek("Vi tri cham - doc (% man hinh)", "mi_ty", 100, 10))
        root.addView(btn("Mo cai dat Tro nang") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(btn("Cho phep cai dat bi han che (Android 13+)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        miPkgs = EditText(this).apply {
            hint = "Ten goi Mi AI (cach nhau dau phay)"
            setText(prefs().getString("mi_pkgs", MiAiWatcher.DEFAULT_PKGS))
        }
        root.addView(miPkgs)
        root.addView(seek("Do tre truoc khi goi Gemini (ms)", "mi_delay", 1500, 350))

        root.addView(TextView(this).apply {
            text = "\nHIEU UNG AM THANH\nPhat am thanh khi Gemini hien len: giu nut nguon, goi giong noi (qua Mi AI) hoac dung thanh. Can bat Tro nang cho Gemini Guard de nhan ra khi giu nut nguon."
            textSize = 14f
        })
        root.addView(sw("Phat am thanh khi Gemini hien len", "snd_on", false))
        root.addView(seek("Am luong hieu ung (%)", "snd_vol", 100, 100))
        root.addView(seek("Khuech dai them (dB, 0 = tat)", "snd_gain", 15, 0))
        root.addView(seek("Bo qua dau am thanh de bot tre (ms)", "snd_skip", 600, 0))
        root.addView(seek("Chong lap am thanh (giay)", "snd_gap_s", 10, 3))
        sndCls = EditText(this).apply {
            hint = "Loc ten cua so Google (tuy chon, de trong = moi cua so)"
            setText(prefs().getString("snd_cls", ""))
        }
        root.addView(sndCls)
        root.addView(btn("Thu am thanh") { GeminiSound.play(this, force = true) })

        root.addView(btn("Sao chep cai dat lien quan Mi AI / nut nguon") {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("settings", Restorer.dumpRelated(this)))
            Toast.makeText(this, "Da sao chep - dan vao chat gui cho Claude", Toast.LENGTH_LONG).show()
        })
        root.addView(btn("Cai dat pin / tu khoi dong cua app") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        root.addView(btn("Sao chep trang thai") {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("status", status.text))
            Toast.makeText(this, "Da sao chep", Toast.LENGTH_SHORT).show()
        })
        status = TextView(this).apply { textSize = 13f; setPadding(0, 30, 0, 0); setTextIsSelectable(true) }
        root.addView(status)

        setContentView(ScrollView(this).apply {
            addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
        pushService()
    }

    override fun onResume() { super.onResume(); refresh(); pushService() }
    override fun onPause() {
        super.onPause()
        val t = ctsPkg.text.toString().trim()
        if (t.isNotEmpty()) prefs().edit().putString("cts_pkg", t).apply()
        prefs().edit().putString("snd_cls", sndCls.text.toString().trim()).apply()
        val m = miPkgs.text.toString().trim()
        if (m.isNotEmpty()) prefs().edit().putString("mi_pkgs", m).apply()
        pushService()
    }

    private fun refresh() {
        val vis = if (Restorer.hasPermission(this)) View.GONE else View.VISIBLE
        warn.visibility = vis; warnBtn.visibility = vis
        val pkg = prefs().getString("cts_pkg", "com.parallelc.micts") ?: ""
        val cts = packageManager.getLaunchIntentForPackage(pkg) != null
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "?" }
        status.text = "Gemini Guard v$ver\n\n" + Restorer.status(this) +
            "\n\nQuyen hien thi tren app khac: " + (if (Settings.canDrawOverlays(this)) "OK" else "CHUA CAP") +
            "\nMiCTS ($pkg): " + (if (cts) "da cai" else "CHUA CAI") +
            "\n\nCua so Google vua thay (moi nhat truoc):\n" +
            (prefs().getString("gseen", "")?.ifBlank { "(chua co)" } ?: "") +
            "\n\nApp vua thay (de tim ten goi Mi AI, moi nhat truoc):\n" +
            (prefs().getString("seen", "")?.ifBlank { "(chua co - bat Tro nang roi goi Mi AI)" } ?: "")
    }
}
