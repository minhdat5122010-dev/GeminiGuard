package com.gemini.guard

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.SystemClock

/** Phat hieu ung am thanh (res/raw/gemini_sound.mp3) khi Gemini hien len. */
object GeminiSound {
    @Volatile var lastPlay = 0L

    fun play(ctx: Context, minGapMs: Long = 1500, force: Boolean = false) {
        val app = ctx.applicationContext
        val pr = Restorer.prefs(app)
        if (!force && !pr.getBoolean("snd_on", false)) return
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastPlay < minGapMs) return
        lastPlay = now
        try {
            val vol = pr.getInt("snd_vol", 100) / 100f
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            val afd = app.resources.openRawResourceFd(R.raw.gemini_sound)
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            mp.setVolume(vol, vol)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener { it.release() }
            mp.setOnErrorListener { m, _, _ -> m.release(); true }
            mp.prepareAsync()
        } catch (_: Throwable) {}
    }
}
