package com.gemini.guard

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.SystemClock

/**
 * Phat hieu ung am thanh (res/raw/gemini_sound.mp3) khi Gemini hien len.
 * Luon giu san 1 MediaPlayer da prepare de bam la phat ngay (giam tre), roi chuan bi cai ke tiep.
 */
object GeminiSound {
    @Volatile var lastPlay = 0L
    private val lock = Any()
    private var ready: MediaPlayer? = null
    private var preparing = false

    private fun build(app: Context, onReady: (MediaPlayer) -> Unit) {
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            val afd = app.resources.openRawResourceFd(R.raw.gemini_sound)
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            mp.setOnPreparedListener { onReady(it) }
            mp.setOnErrorListener { m, _, _ ->
                m.release()
                synchronized(lock) { preparing = false; if (ready === m) ready = null }
                true
            }
            mp.prepareAsync()
        } catch (_: Throwable) {
            synchronized(lock) { preparing = false }
        }
    }

    /** Chuan bi san 1 player (goi luc service khoi dong va sau moi lan phat). */
    fun warm(ctx: Context) {
        val app = ctx.applicationContext
        synchronized(lock) { if (ready != null || preparing) return; preparing = true }
        build(app) { mp -> synchronized(lock) { ready = mp; preparing = false } }
    }

    fun play(ctx: Context, minGapMs: Long = 1500, force: Boolean = false) {
        val app = ctx.applicationContext
        val pr = Restorer.prefs(app)
        if (!force && !pr.getBoolean("snd_on", false)) return
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastPlay < minGapMs) return
        lastPlay = now

        val mp = synchronized(lock) { val r = ready; ready = null; r }
        if (mp != null) start(mp, app) else build(app) { start(it, app) }
        warm(app)
    }

    private fun start(mp: MediaPlayer, app: Context) {
        try {
            val pr = Restorer.prefs(app)
            val vol = pr.getInt("snd_vol", 100) / 100f
            val skip = pr.getInt("snd_skip", 0)
            mp.setVolume(vol, vol)
            mp.setOnCompletionListener { it.release() }
            if (skip > 0) {
                mp.setOnSeekCompleteListener { it.start() }
                mp.seekTo(skip)
            } else mp.start()
        } catch (_: Throwable) { try { mp.release() } catch (_: Throwable) {} }
    }
}
