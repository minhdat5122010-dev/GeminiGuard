package com.gemini.guard

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Restorer.ensure(c)
        val pr = Restorer.prefs(c)
        if (pr.getBoolean("enabled", true) || pr.getBoolean("bar", false)) {
            try { c.startForegroundService(Intent(c, GuardService::class.java)) } catch (_: Exception) {}
        }
    }
}
