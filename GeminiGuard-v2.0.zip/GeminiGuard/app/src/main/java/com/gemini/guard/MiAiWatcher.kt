package com.gemini.guard

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Nhan biet Mi AI / XiaoAi vua bat len (giu nut nguon...) -> tu goi Gemini de len tren.
 * Ghi lai cac package vua thay de ban biet ten goi dung cua Mi AI tren may.
 */
class MiAiWatcher : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastFire = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        val pr = Restorer.prefs(this)
        if (!pr.getBoolean("mi_on", false)) return

        remember(pkg)

        val targets = (pr.getString("mi_pkgs", DEFAULT_PKGS) ?: DEFAULT_PKGS)
            .split(",", ";", " ", "\n").map { it.trim() }.filter { it.isNotEmpty() }
        if (pkg !in targets) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastFire < 4000) return   // chong lap
        lastFire = now

        // Dong Mi AI truoc (Back), doi no dong xong roi moi goi Gemini
        if (pr.getBoolean("mi_back", true)) performGlobalAction(GLOBAL_ACTION_BACK)

        handler.postDelayed({
            Restorer.ensure(this)
            val err = GeminiCall.show()
            if (err != null) Toast.makeText(this, "Khong goi duoc Gemini: $err", Toast.LENGTH_LONG).show()
        }, pr.getInt("mi_delay", 350).toLong())
    }

    private fun remember(pkg: String) {
        if (pkg in IGNORE) return
        val pr = Restorer.prefs(this)
        val old = (pr.getString("seen", "") ?: "").split("\n").filter { it.isNotBlank() && it != pkg }
        pr.edit().putString("seen", (listOf(pkg) + old).take(8).joinToString("\n")).apply()
    }

    override fun onInterrupt() {}

    companion object {
        const val DEFAULT_PKGS = "com.miui.voiceassist"
        private val IGNORE = setOf(
            "com.android.systemui", "com.miui.home", "com.mi.android.globallauncher",
            "com.google.android.googlequicksearchbox", "com.android.settings", "android"
        )
    }
}
