package com.gemini.guard

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

/**
 * Nhan biet Mi AI / XiaoAi vua bat len (giu nut nguon...) -> tu goi Gemini de len tren.
 * Ghi lai cac package vua thay de ban biet ten goi dung cua Mi AI tren may.
 */
class MiAiWatcher : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastFire = 0L
    private var lastGoogleEvt = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (pkg == GOOGLE_PKG) { onGoogleWindow(e); return }
        val pr = Restorer.prefs(this)
        if (!pr.getBoolean("mi_on", false)) return

        remember(pkg, "$pkg  ${e.className}")

        val targets = (pr.getString("mi_pkgs", DEFAULT_PKGS) ?: DEFAULT_PKGS)
            .split(",", ";", " ", "\n").map { it.trim() }.filter { it.isNotEmpty() }
        if (pkg !in targets) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastFire < 4000) return   // chong lap
        lastFire = now

        // Dong Mi AI truoc (Back), doi no dong xong roi moi goi Gemini
        if (pr.getBoolean("mi_back", true)) performGlobalAction(GLOBAL_ACTION_BACK)

        // Cham vao cho trong de dong thanh Mi AI
        if (pr.getBoolean("mi_swipe", false)) tapOutside()

        handler.postDelayed({
            // Thu dung tien trinh Mi AI (co the khong tac dung neu la tien trinh he thong)
            try { (getSystemService(ACTIVITY_SERVICE) as android.app.ActivityManager).killBackgroundProcesses(pkg) } catch (_: Throwable) {}
            Restorer.ensure(this)
            val err = GeminiCall.show()
            if (err == null) GeminiSound.play(this)
            else Toast.makeText(this, "Khong goi duoc Gemini: $err", Toast.LENGTH_LONG).show()
        }, pr.getInt("mi_delay", 350).toLong())
    }

    /** Cua so cua app Google (Gemini overlay) vua hien -> phat am thanh (ca khi giu nut nguon / goi giong noi). */
    private fun onGoogleWindow(e: AccessibilityEvent) {
        val pr = Restorer.prefs(this)
        val now = SystemClock.elapsedRealtime()
        val cls = e.className?.toString() ?: ""
        val old = (pr.getString("gseen", "") ?: "").split("\n").filter { it.isNotBlank() && it != cls }
        pr.edit().putString("gseen", (listOf(cls) + old).take(8).joinToString("\n")).apply()

        val filter = pr.getString("snd_cls", "")?.trim().orEmpty()
        val gap = pr.getInt("snd_gap_s", 3) * 1000L
        val fresh = now - lastGoogleEvt > gap      // phien moi, khong phai su kien tiep noi
        lastGoogleEvt = now
        if (fresh && pr.getBoolean("snd_on", false) &&
            (filter.isEmpty() || cls.contains(filter, ignoreCase = true)) &&
            now - GeminiSound.lastPlay > gap) GeminiSound.play(this, 0)
    }

    private fun remember(pkg: String, line: String) {
        if (pkg in IGNORE) return
        val pr = Restorer.prefs(this)
        val old = (pr.getString("seen", "") ?: "").split("\n").filter { it.isNotBlank() && it != line }
        pr.edit().putString("seen", (listOf(line) + old).take(10).joinToString("\n")).apply()
    }

    /** Cham 1 cai vao cho trong (ngoai thanh Mi AI) de no tu dong. Toa do theo % man hinh. */
    private fun tapOutside() {
        try {
            val pr = Restorer.prefs(this)
            val dm = resources.displayMetrics
            val x = dm.widthPixels * pr.getInt("mi_tx", 8) / 100f
            val y = dm.heightPixels * pr.getInt("mi_ty", 10) / 100f
            val path = Path().apply { moveTo(x, y) }
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 40)).build()
            dispatchGesture(g, null, null)
        } catch (_: Throwable) {}
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        GeminiSound.warm(this)
    }

    override fun onInterrupt() {}

    companion object {
        const val DEFAULT_PKGS = "com.miui.voiceassist"
        const val GOOGLE_PKG = "com.google.android.googlequicksearchbox"
        private val IGNORE = setOf(
            "com.android.systemui", "com.miui.home", "com.mi.android.globallauncher",
            "com.google.android.googlequicksearchbox", "com.android.settings", "android"
        )
    }
}
