package com.gemini.guard

import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Restorer {
    const val GOOGLE_ASSIST =
        "com.google.android.googlequicksearchbox/com.google.android.voiceinteraction.GsaVoiceInteractionService"
    private val SECURE_KEYS = listOf("assistant", "voice_interaction_service")
    private const val POWER_KEY = "power_button_long_press"
    private const val POWER_VALUE = 5

    fun prefs(c: Context) = c.getSharedPreferences("guard", Context.MODE_PRIVATE)

    fun hasPermission(c: Context) =
        c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED

    /** Ghi lại giá trị đúng nếu bị đổi. Trả về mô tả những gì đã sửa. */
    fun ensure(c: Context): List<String> {
        val changes = mutableListOf<String>()
        if (!hasPermission(c)) return changes
        val r = c.contentResolver
        try {
            for (k in SECURE_KEYS) {
                val cur = Settings.Secure.getString(r, k)
                if (cur != GOOGLE_ASSIST) {
                    Settings.Secure.putString(r, k, GOOGLE_ASSIST)
                    changes += "$k: [${cur ?: "null"}] -> Google"
                }
            }
            val p = Settings.Global.getInt(r, POWER_KEY, -1)
            if (p != POWER_VALUE) {
                Settings.Global.putInt(r, POWER_KEY, POWER_VALUE)
                changes += "$POWER_KEY: [$p] -> $POWER_VALUE"
            }
        } catch (e: SecurityException) {
            changes += "Loi quyen: ${e.message}"
        }
        if (changes.isNotEmpty()) log(c, changes.joinToString("; "))
        return changes
    }

    private fun log(c: Context, msg: String) {
        val t = SimpleDateFormat("dd/MM HH:mm:ss", Locale.US).format(Date())
        val old = prefs(c).getString("log", "") ?: ""
        val lines = (listOf("$t  $msg") + old.split("\n").filter { it.isNotBlank() }).take(10)
        prefs(c).edit().putString("log", lines.joinToString("\n")).apply()
    }

    fun status(c: Context): String {
        val r = c.contentResolver
        val sb = StringBuilder()
        sb.append("Quyen WRITE_SECURE_SETTINGS: ").append(if (hasPermission(c)) "OK" else "CHUA CAP").append("\n")
        for (k in SECURE_KEYS) {
            val v = Settings.Secure.getString(r, k)
            sb.append(k).append(": ").append(if (v == GOOGLE_ASSIST) "Google OK" else "[${v ?: "trong"}] SAI").append("\n")
        }
        sb.append(POWER_KEY).append(": ").append(Settings.Global.getInt(r, POWER_KEY, -1)).append("\n")
        sb.append("\nNhat ky tu sua (moi nhat truoc):\n")
        sb.append(prefs(c).getString("log", "")?.ifBlank { "(chua co)" } ?: "(chua co)")
        return sb.toString()
    }
}
