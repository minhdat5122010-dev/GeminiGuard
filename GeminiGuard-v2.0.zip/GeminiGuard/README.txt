GEMINI GUARD 4.0
- Upload zip nay len GitHub (cung ten GeminiGuard-v2.0.zip de ghi de, repo chi nen co 1 file zip). Actions tu build APK.
- Cai APK DE LEN ban cu (khong go app) de giu quyen ADB.
- Cap quyen 1 lan: pm grant com.gemini.guard android.permission.WRITE_SECURE_SETTINGS
- Phim tat Tro nang: o "Tro nang Gemini Guard" trong Control Center (muc Phim nhanh ung dung),
  hoac nhan giu icon app -> "Bat/tat Tro nang".
