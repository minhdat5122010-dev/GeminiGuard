GEMINI GUARD v2.0
1) Build: day len GitHub -> tab Actions -> artifact GeminiGuard-apk. Hoac push tag (vd: git tag v2.0 && git push --tags) de tu tao Release co file APK.
2) Cai APK len may. Cap nhat: CAI DE LEN BAN CU (cung khoa ky, versionCode tu tang theo moi lan build). KHONG go cai dat vi se mat quyen ADB.
3) Cap quyen 1 lan qua ADB:
   adb shell pm grant com.gemini.guard android.permission.WRITE_SECURE_SETTINGS
4) Mo app, bat cong tac. Khoa app trong da nhiem, tat toi uu pin, bat Tu khoi dong.
